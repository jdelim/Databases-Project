import java.io.*;
import java.sql.*;
import java.sql.Date;

public class PlayersInsert {

    // command lines used: javac PlayersInsert.java
    // java -cp mysql-connector-j-8.0.31.jar;. PlayersInsert players.csv
    // note: include the sqlconnector jar file and players.csv file in same folder as PlayersInsert.java

    public static void main(String[] args) {

        // take in players.csv as command line argument
        String csv = "";
        for (String val : args) {
            if (val.equals("players.csv")) {
                csv = val;
            }
        }

        String jdbcURL = "jdbc:mysql://localhost:3306/resulttrackerjadrieldelim";
        String username = "root";
        String password = "root";

        //String csvFilePath = "C:\\Users\\Jadriel delim\\Desktop\\Databases Project Data\\" + csv;
        String csvFilePath = csv;

        // use batch feature for better performance?, 20 statements at a time
        int batchSize = 20;
        Connection connection = null;

        try {
            System.out.println("Connecting to Database...");
            connection = DriverManager.getConnection(jdbcURL, username, password);
            connection.setAutoCommit(false);

            String sql = "INSERT INTO players (player_id, tag, real_name, nationality, birthday, game_race)" +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement statement = connection.prepareStatement(sql);

            //read in csv file
            BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath));
            String lineText;

            int count = 0;

            // traverse through csv file
            while ((lineText = lineReader.readLine()) != null) {
                String[] data = lineText.split(",");
                String player_id = data[0];
                String tag = data[1];
                String real_name = data[2];
                String nationality = data[3];
                String birthday = data[4];
                String game_race = data[5];

                // remove extra "s
                int intPlayer_id = Integer.parseInt(player_id);
                tag = tag.replace("\"", "");
                real_name = real_name.replace("\"", "");
                birthday = birthday.replace("\"", "");
                nationality = nationality.replace("\"", "");
                game_race = game_race.replace("\"","");
                Date dateBirthday = Date.valueOf(birthday);

                statement.setInt(1, intPlayer_id);
                statement.setString(2, tag);
                statement.setString(3, real_name);
                statement.setString(4, nationality);
                statement.setDate(5, dateBirthday);
                statement.setString(6, game_race);

                statement.addBatch();
                count++;

                if (count % batchSize == 0) {
                    statement.executeBatch();
                }
            }

            lineReader.close();

            statement.executeBatch();
            connection.commit();
            connection.close();

        } catch (IOException fi) {
            fi.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
            try {
                // if there is an error, then rollback the changes
                if (connection != null) {
                    connection.rollback();
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
