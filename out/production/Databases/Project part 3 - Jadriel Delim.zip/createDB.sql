CREATE DATABASE ResultTrackerJADRIELDELIM;

USE ResultTrackerJADRIELDELIM;

CREATE TABLE Players (
	player_id INT NOT NULL,
    tag VARCHAR(45) NOT NULL,
    real_name VARCHAR(45) NOT NULL,
    nationality VARCHAR(2) NOT NULL,
    birthday DATE NOT NULL,
    game_race ENUM('P', 'Z', 'T') NOT NULL,
    PRIMARY KEY (player_id)
    );